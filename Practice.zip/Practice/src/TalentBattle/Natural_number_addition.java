package TalentBattle;

import com.sun.xml.internal.ws.api.model.wsdl.WSDLOutput;

public class Natural_number_addition {
    public static void main(String[] args) {
    int n=10;
    int sum= 0;
    for(int i=0; i<=n; i++){
            sum+=i;
    }
    System.out.println(sum);
}
}
