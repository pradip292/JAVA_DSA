package TalentBattle;

public class Store_Water {
    public static void main(String[] args) {
        int a= 7;
        int b= 9;
        double formula= Math.round(3.14 * a*a* b); //(pi*r*r*h)
        System.out.println((int)formula);
    }
}
