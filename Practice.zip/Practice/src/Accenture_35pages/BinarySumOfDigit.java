package Accenture_35pages;

public class BinarySumOfDigit {
    public static void main(String[] args) {
        int n= 15;
//        String str = Integer.toBinaryString(n);
//        int sum=0;
//        for(int i=0; i<str.length(); i++){
//            char ch= str.charAt(i);
//            sum+=ch-'0';
//        }
//        System.out.println(sum);

        int i=0;
        while(n>0){
            int num = n%10;

        }
    }
}
