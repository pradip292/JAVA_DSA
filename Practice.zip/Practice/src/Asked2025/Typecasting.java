package Asked2025;

public class Typecasting {
    public static void main(String[] args) {
        char ch ='5';
        int a= ch -'0';
        System.out.println(a);
    }
}

