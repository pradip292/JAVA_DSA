package Accenture_101pages;

public class _27_8_Climbling_Stars {
    public static void main(String[] args) {
        int n=6;
        int a=4;
        int res= (n/a)+(n%a);
        System.out.println(res);
    }
}
