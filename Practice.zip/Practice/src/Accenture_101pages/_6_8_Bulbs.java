package Accenture_101pages;

public class _6_8_Bulbs {
    public static void main(String[] args) {
        int n=7;
        if(n<=1){
            System.out.println(0);
        }
        else{
            System.out.println((int)Math.sqrt(n));
        }
    }
}
