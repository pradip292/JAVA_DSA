package Accenture_101pages;

public class _28_8_TreesAndSprinklers {
    public static void main(String[] args) {

    }
}
