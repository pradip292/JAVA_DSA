package Accenture_101pages;

public class _28_8_Add_Numbers {
    public static void main(String[] args) {
        int m= -10000;
        int n= 10000;
        int a= -100000;
        int b= 10000;
        if(a>=m && b<=n){
            System.out.println(a+b);
        }
        else{
            System.out.println(-1);
        }
    }
}
